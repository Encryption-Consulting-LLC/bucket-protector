package com.mycompany;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import com.google.cloud.kms.v1.CryptoKey;
import com.google.cloud.kms.v1.CryptoKey.CryptoKeyPurpose;
import com.google.cloud.kms.v1.CryptoKeyVersion.CryptoKeyVersionAlgorithm;
import com.google.cloud.kms.v1.CryptoKeyVersionTemplate;
import com.google.cloud.kms.v1.KeyManagementServiceClient;
import com.google.cloud.kms.v1.KeyRing;
import com.google.cloud.kms.v1.KeyRingName;
import com.google.cloud.kms.v1.LocationName;
import com.google.cloud.kms.v1.EncryptResponse;
import com.google.cloud.kms.v1.CryptoKeyName;
import java.util.*;
import com.google.cloud.dlp.v2.DlpServiceClient;
import com.google.common.io.BaseEncoding;
import com.google.privacy.dlp.v2.ContentItem;
import com.google.privacy.dlp.v2.CryptoReplaceFfxFpeConfig;
import com.google.privacy.dlp.v2.CryptoReplaceFfxFpeConfig.FfxCommonNativeAlphabet;
import com.google.privacy.dlp.v2.DeidentifyConfig;
import com.google.privacy.dlp.v2.DeidentifyContentRequest; 
import com.google.privacy.dlp.v2.DeidentifyContentResponse;
import com.google.privacy.dlp.v2.InfoType;
import com.google.privacy.dlp.v2.CustomInfoType;
import com.google.privacy.dlp.v2.InfoTypeTransformations;
import com.google.privacy.dlp.v2.InfoTypeTransformations.InfoTypeTransformation;
import com.google.privacy.dlp.v2.InspectConfig;
import com.google.privacy.dlp.v2.KmsWrappedCryptoKey;
import com.google.privacy.dlp.v2.PrimitiveTransformation;
import com.google.protobuf.ByteString;
import java.util.Arrays;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import java.io.*;
import static org.apache.commons.codec.binary.Hex.encodeHex;
import java.security.Key;
import java.security.SecureRandom;
import com.google.privacy.dlp.v2.ReplaceValueConfig;
import com.google.privacy.dlp.v2.Value;
import com.google.privacy.dlp.v2.RedactConfig;
import com.google.privacy.dlp.v2.CharacterMaskConfig;
import com.google.privacy.dlp.v2.ReplaceWithInfoTypeConfig;
import com.google.privacy.dlp.v2.DateShiftConfig;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import com.google.common.base.Splitter;
import java.io.BufferedReader;
import com.google.privacy.dlp.v2.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import com.google.type.Date;
import java.lang.*;
import com.google.cloud.functions.BackgroundFunction;
import com.google.cloud.functions.Context;
import functions.eventpojos.GcsEvent;
import org.json.simple.*;
import org.json.simple.parser.*;
import com.google.cloud.storage.*;
import com.google.cloud.storage.StorageOptions;
import com.google.cloud.storage.Storage;

//NEED: Aes key to be searched for in wrapped keys file
public class EncryptionToBucket implements  BackgroundFunction<GcsEvent>{

  private String aesKey, bucketName, uploadedFile, wrappingKeyRing, wrappingKey, projectId, locationId, protectedBucket, maskingChar, replaceItem, numToMask, surrogateInfoTypeName, aesKeyFromFile, originalWrappingKey, originalWrappingKeyRing, originalSurrogateInfoTypeName;
  private static List<FieldId> headers;
  private Table table;
  private String[] itypeStringArray;
  private static String testingSurrInfoType;

  @Override
  public void accept(GcsEvent gcsEvent, Context context){
     //Returns the bucket name of the event triggering bucket
     bucketName = gcsEvent.getBucket();
     //Returns the name of the file that triggered the Google Cloud Function
     uploadedFile = gcsEvent.getName();
    
     //Ensures that the file loaded into the bucket is not cloudFuncConfig.json, since that gets read once the csv file is uploaded to the bucket
     if(!uploadedFile.equals("cloudFuncConfig.json")){
      readJsonConfig();
      writeToBucket();
     }
  }
  
  //This function writes the deidentified and encrypted csv file into the bucket created for protected data
  public void writeToBucket(){
     //Creates an instance of Google Cloud Storage to get items from buckets
     Storage storage = StorageOptions.newBuilder().setProjectId(projectId).build().getService();
     String protectedString;
     try{
      //Collects the headers from the deidentified table
      String headerOut =
        table.getHeadersList().stream()
          .map(FieldId::getName) 
          .collect(Collectors.joining(","));
      protectedString = headerOut + "\n";
          
      //Collects the rows from the deidentified table
      List<String> rowOutput =
        table.getRowsList().stream()
          .map(row -> joinIntoRow(row.getValuesList()))
          .collect(Collectors.toList());
           
      //Writes the headers and rows into one string     
      for (String line : rowOutput) {
        protectedString = protectedString + line + "\n";
      }
      //Turns the deidentified string into a byte array for putting the file into the protected bucket
      byte[] byteArray = protectedString.getBytes();
      //Writes the protected table into the protected bucket
      BlobId blobId = BlobId.of(protectedBucket, "protected" + uploadedFile);
      BlobInfo blobInfo = BlobInfo.newBuilder(blobId).build();
      storage.create(blobInfo, byteArray);

     }catch(Exception e){
      System.out.println(e);
     }
  }

  //This function takes the values in the rows of the table and joins them into their rows to be put into the protected csv file
  public static String joinIntoRow(List<Value> values){
     String finalValue = "";
     String temp = "";
     int numVals = values.size();
     //Puts all of the rows into one string seperated by commas
     for(int i = 0; i < numVals; i++){
      //System.out.println(values.get(i).getStringValue());
      temp = values.get(i).getStringValue();
      if(i+1 == numVals){
         //System.out.println("test1");
         if(temp.contains(testingSurrInfoType)){
          int subStringBegin = temp.indexOf(':') + 1;
          //System.out.println(subStringBegin);
          int subStringEnd = temp.length() - 1;
          //System.out.println(subStringEnd);
          temp = temp.substring(subStringBegin, subStringEnd);
          //System.out.println(temp);
          finalValue = finalValue + temp;
          //System.out.println(finalValue);
          /*System.out.println(temp.substring(subStringBegin, subStringEnd));*/
         //System.out.println(temp + " contains surrogateInfoTypeName.");
         // System.out.println(temp.replace(surrogateInfoTypeName + "(" +  + ")", ));
         }else{
          //temp = values.get(i).getStringValue();
          finalValue = finalValue + temp;
         }
       }else{
        System.out.println(temp.contains(testingSurrInfoType));
        if(temp.contains(testingSurrInfoType)){
          System.out.println("contains");
          int subStringBegin = temp.indexOf(':') + 1;
          //System.out.println(subStringBegin);
          int subStringEnd = temp.length();
          //System.out.println(subStringEnd);
          temp = temp.substring(subStringBegin, subStringEnd);
         // System.out.println(temp);
          finalValue = finalValue + temp + ",";
          //System.out.println(finalValue);
          //System.out.println(temp.substring(subStringBegin, subStringEnd));
         //System.out.println(temp + " contains surrogateInfoTypeName.");
         // System.out.println(temp.replace(surrogateInfoTypeName + "(" +  + ")", ));
        }else{
          //temp = values.get(i).getStringValue();
          finalValue = finalValue + temp + ",";
        }
      }
      System.out.println("final value number " + i + " " + finalValue);
     }
     //Returns the rows as one string
     //System.out.println(finalValue);
     return finalValue;
  }

   //This function parses and reads the json file and applies the appropriate deidentification/encryption techniques
  
  public void readJsonConfig(){
     Storage storageInst = StorageOptions.newBuilder().setProjectId(projectId).build().getService();
     //An instance of the JSON file is created and read into the program as a string
     Blob testBlob = storageInst.get(BlobId.of(bucketName, "cloudFuncConfig.json")); 
     String  blobContent = new String(testBlob.getContent());

     try{ 
      //The JSON file is parsed and read
      JSONParser parser = new JSONParser();
      JSONObject obj = (JSONObject) parser.parse(blobContent);
      JSONArray jsonArray = new JSONArray();
      jsonArray.add(obj);
      JSONObject object = (JSONObject) jsonArray.get(0);
      //The project id, location id, and the bucket name to put files into after they are deidentified/encrypted are extracted from the 
      //user_info section of the JSON file
      JSONObject userInfo = (JSONObject) object.get("user_info");
      projectId = (String) userInfo.get("project_id");
      locationId = (String) userInfo.get("location_id");
      protectedBucket = (String) userInfo.get("protected_bucket");
      //The file that triggered the Google Cloud Function is read into the program
      readInputFile();

      JSONArray encryptingMethods = new JSONArray();
      encryptingMethods = (JSONArray) object.get("encrypting");
      int i, j;
      for(i = 0; i < encryptingMethods.size(); i++){
         //For each method that a user wants to apply to their csv, the method and appropriate info for each method of deidentification/encryption
         //are collected from the JSON file
         JSONObject temp = (JSONObject) encryptingMethods.get(i);
         String currMethod = (String) temp.get("method");
         JSONArray itypeJsonArray = new JSONArray();
         List<String> itypeList = new ArrayList<String>();

         //The methods selected by the user in the JSON file are read in, and appropriate information is taken from the JSON file and the method
         //of deidentification/encryption is carried out
         if(currMethod.equals("Replacement")){
             replaceItem = (String) temp.get("replacement_string");
             itypeJsonArray = (JSONArray) temp.get("info_types");
             for(j=0; j < itypeJsonArray.size(); j++) {
                 itypeList.add((String) itypeJsonArray.get(j));
             }
             itypeStringArray = itypeList.toArray(new String[itypeList.size()]);
             replacementEncryption();
          }else if(currMethod.equals("FPE Encryption")){
             surrogateInfoTypeName = (String) temp.get("surrogate_info_type");
             testingSurrInfoType = surrogateInfoTypeName;
             itypeJsonArray = (JSONArray) temp.get("info_types");
             wrappingKey = (String) temp.get("wrapping_key");
             wrappingKeyRing = (String) temp.get("wrapping_key_ring");
      
             for(j=0; j < itypeJsonArray.size(); j++) {
                 itypeList.add((String) itypeJsonArray.get(j));
             }
             itypeStringArray = itypeList.toArray(new String[itypeList.size()]);
             fpeEncryption();
          }else if(currMethod.equals("Redaction")){
             itypeJsonArray = (JSONArray) temp.get("info_types");
             for(j=0; j < itypeJsonArray.size(); j++) {
                 itypeList.add((String) itypeJsonArray.get(j));
             }
             itypeStringArray = itypeList.toArray(new String[itypeList.size()]);
             redactionEncryption();
          }else if(currMethod.equals("Masking")){
             maskingChar = (String) temp.get("masking_character");
             numToMask = (String) temp.get("number_to_mask");
             itypeJsonArray = (JSONArray) temp.get("info_types");
             for(j=0; j < itypeJsonArray.size(); j++) {
                itypeList.add((String) itypeJsonArray.get(j));
             }
             itypeStringArray = itypeList.toArray(new String[itypeList.size()]);
             maskingEncryption();
          }else if(currMethod.equals("FPE Decryption")){
             originalSurrogateInfoTypeName = (String) temp.get("surrogate_info_type");
             originalWrappingKey = (String) temp.get("wrapping_key");
             originalWrappingKeyRing = (String) temp.get("wrapping_key_ring");
             fpeDecryption();
          }
      }

     }catch(Exception e){
      System.out.println(e);
     }
  }

  //This function reads teh trigger file into the program
  public void readInputFile(){
     Storage storageInst = StorageOptions.newBuilder().setProjectId(projectId).build().getService();
     //The information in the uploaded file is read into a string in the program
     Blob testBlob = storageInst.get(BlobId.of(bucketName, uploadedFile));
     String  blobContent = new String(testBlob.getContent());
     
     try (DlpServiceClient dlp = DlpServiceClient.create()) {
        List<Table.Row> rows = new ArrayList<>();
        //The csv file is first split by the \r\n characters in the file
        String[] splitString = blobContent.split("\r\n");
        String finalString = "";
          
        //The headers of the CSV file are split at the commas and read into the table as headers
        headers =
          Arrays.stream(splitString[0].split(","))
            .map(header -> FieldId.newBuilder().setName(header).build())
            .collect(Collectors.toList());

        //Puts all the rows into one string
        for(int i = 1; i < splitString.length; i++){
            if(i == 1){
              finalString = finalString + splitString[i];
            }else{
              finalString = finalString + "\r\n" + splitString[i];
            }
        }
        //Reads the row string into the table 
        rows =
          Arrays.stream(finalString.split("\r\n"))
            .map(EncryptionToBucket::lineToRow)
            .collect(Collectors.toList());

        table = Table.newBuilder().addAllHeaders(headers).addAllRows(rows).build();

        dlp.close();

     }catch(Exception e){ 
        e.printStackTrace();
     }
  }

  //Converts the row string into table rows
  public static Table.Row lineToRow(String line) {
     List<String> valuesAsString = Splitter.on(",").splitToList(line);
     List<Value> values = new ArrayList<>();
     int numVals = valuesAsString.size();
     for(int i = 0; i < numVals; i++){
        values.add(i, Value.newBuilder().setStringValue(valuesAsString.get(i)).build()); 
     }
    
     return Table.Row.newBuilder().addAllValues(values).build();
  }

  //CHECK IF KEY ALREADY CREATED
  //Creates the aes key for FPE
  public void aesKeyCreation(){
     try(KeyManagementServiceClient kmsClient = KeyManagementServiceClient.create()){ 

      //Creates a key generator that generates aes keys
      KeyGenerator keyGen = KeyGenerator.getInstance("AES");
      
      //Creates a SecureRandom object to ensure the creation of secure aes keys
      SecureRandom secRandom = new SecureRandom();
      
      //Initializing the KeyGenerator
      keyGen.init(256, secRandom);
      
      //Creates an AES key and converts it to a byte array
      Key key = keyGen.generateKey();
      byte[] encodedKey = key.getEncoded();

      //The wrapping key is collected
      CryptoKeyName keyVersionName = CryptoKeyName.of(projectId, "global", wrappingKeyRing, wrappingKey);
       
      //The key is wrapped and returned as a wrapped aes key
      EncryptResponse response = kmsClient.encrypt(keyVersionName, ByteString.copyFrom(encodedKey));
      byte[] responseBytes = response.getCiphertext().toByteArray();
      aesKey = Base64.getEncoder().encodeToString(responseBytes);
      
      Storage storage = StorageOptions.newBuilder().setProjectId(projectId).build().getService();
      BlobId blobId = BlobId.of(protectedBucket, "wrapped_keys.json");
     
      try{
        if(storage.get(blobId) == null){
          String initialContent = "{\n\t\"keys:\" [\n\t\t{\n\t\t\t\"name\": \"" + uploadedFile + "\",\n\t\t\t\"key_id\": \"" + wrappingKey + "\",\n\t\t\t\"key_ring_id\": \"" + wrappingKeyRing + "\",\n\t\t\t\"wrapped_key\": \"" + aesKey + "\"\n\t\t}\n\t]\n}";
          byte[] initialContentBytes = initialContent.getBytes();
          BlobInfo blobInfo = BlobInfo.newBuilder(blobId).build();
          storage.create(blobInfo, initialContentBytes);
        }else{
          Blob testBlob = storage.get(blobId);
          String blobContent = new String(testBlob.getContent());
          //System.out.println(blobContent);
       	  String toReplace = "}\n\t]\n}";
       	  String replacementString  = "},\n\t\t{\n\t\t\t\"name\": \"" + uploadedFile + "\",\n\t\t\t\"key_id\": \"" + wrappingKey + "\",\n\t\t\t\"key_ring_id\": \"" + wrappingKeyRing + "\",\n\t\t\t\"wrapped_key\": \"" + aesKey + "\"\n\t\t}\n\t]\n}";
          String stringForJson = blobContent;
          stringForJson = stringForJson.replace(toReplace, replacementString);
          byte[] stringForJsonBytes = stringForJson.getBytes();
          BlobInfo blobInfo = BlobInfo.newBuilder(blobId).build();
          storage.create(blobInfo, stringForJsonBytes);
        }
      }catch(Exception e){
        System.out.println(e);
      }

      kmsClient.close();

     }catch(Exception e){
      System.out.println(e);
     }      
  }

  //This function encrypts the selected info types with FPE
  public void fpeEncryption(){

     try (DlpServiceClient dlp = DlpServiceClient.create()) {
      //Sets the info types collected from the input csv file
      List<InfoType> finalITTypesList = new ArrayList<>();
      InfoType base; 
      for(int i = 0; i < itypeStringArray.length; i++){
          base = InfoType.newBuilder().setName(itypeStringArray[i]).build();
          finalITTypesList.add(base);
      }
      //The csv file uploaded is set for encryption, and the info types to search for are selected
      ContentItem contentItem = ContentItem.newBuilder().setTable(table).build();
      InspectConfig inspectConfig = InspectConfig.newBuilder().addAllInfoTypes(finalITTypesList).build();

      //The path to the wrapping key is saved
      String keyPath = "projects/" + projectId + "/locations/global/keyRings/" + wrappingKeyRing + "/cryptoKeys/" + wrappingKey;

      //The aes key is created and saved
      aesKeyCreation();
      
      //The aes key is wrapped, so Google Cloud Platform can perform encryption with the wrapped key
      KmsWrappedCryptoKey kmsWrappedCryptoKey = KmsWrappedCryptoKey.newBuilder()
        .setWrappedKey(ByteString.copyFrom(BaseEncoding.base64().decode(aesKey))) 
        .setCryptoKeyName(keyPath)
        .build();
      com.google.privacy.dlp.v2.CryptoKey cryptoKey = com.google.privacy.dlp.v2.CryptoKey.newBuilder().setKmsWrapped(kmsWrappedCryptoKey).build();

      //The surrogate info type given in the Configuration json is specified
      InfoType surrogateInfoType = InfoType.newBuilder().setName(surrogateInfoTypeName).build();
          
      //The alphabet, wrapped key, and surrogate info type are put into the FPE Config
      CryptoReplaceFfxFpeConfig cryptoReplaceFfxFpeConfig = CryptoReplaceFfxFpeConfig.newBuilder()
        .setCryptoKey(cryptoKey)
        .setCustomAlphabet("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890@.~!-()+ ")
        .setSurrogateInfoType(surrogateInfoType)
        .build();
          
      PrimitiveTransformation primitiveTransformation = PrimitiveTransformation.newBuilder().setCryptoReplaceFfxFpeConfig(cryptoReplaceFfxFpeConfig).build();
         
      InfoTypeTransformation infoTypeTransformation = InfoTypeTransformation.newBuilder()
        .setPrimitiveTransformation(primitiveTransformation)
        .build();
          
      InfoTypeTransformations transformations = InfoTypeTransformations.newBuilder().addTransformations(infoTypeTransformation).build();
          
      DeidentifyConfig deidentifyConfig = DeidentifyConfig.newBuilder().setInfoTypeTransformations(transformations).build();

      //The Request to encrypt the given data is created for this project
      DeidentifyContentRequest request = DeidentifyContentRequest.newBuilder()
        .setParent(LocationName.of(projectId, "global").toString())
        .setItem(contentItem)
        .setInspectConfig(inspectConfig)
        .setDeidentifyConfig(deidentifyConfig)
        .build();

      //A response containing the encrypted table is returned and saved
      DeidentifyContentResponse response = dlp.deidentifyContent(request);
      //System.out.println(response.getItem().getTable());
      table = response.getItem().getTable();
      dlp.close();
     }catch(Exception e){
      System.out.println(e);
     }
  }

  //This function deidentifies the selected info types with character masking
  public void maskingEncryption(){
     //Sets the info types collected from the input csv file
     List<InfoType> finalITTypesList = new ArrayList<>();
     InfoType base; 
     for(int i = 0; i < itypeStringArray.length; i++){
         base = InfoType.newBuilder().setName(itypeStringArray[i]).build();
         finalITTypesList.add(base);
     }

     try (DlpServiceClient dlp = DlpServiceClient.create()) {
      //The csv file uploaded is set for deidentification, and the info types to search for are selected
      ContentItem contentItem = ContentItem.newBuilder().setTable(table).build();
      InspectConfig inspectConfig = InspectConfig.newBuilder().addAllInfoTypes(finalITTypesList).build();
        
      // The character to mask with and the amount of characters to mask are specified
      CharacterMaskConfig characterMaskConfig = CharacterMaskConfig.newBuilder()
        .setMaskingCharacter(maskingChar) 
        .setNumberToMask(Integer.parseInt(numToMask)) 
        .build();
          
      PrimitiveTransformation primitiveTransformation = PrimitiveTransformation.newBuilder()
        .setCharacterMaskConfig(characterMaskConfig)
        .build();

      InfoTypeTransformation infoTypeTransformation = InfoTypeTransformation.newBuilder()
        .setPrimitiveTransformation(primitiveTransformation)
        .build();
          
      InfoTypeTransformations transformations =InfoTypeTransformations.newBuilder().addTransformations(infoTypeTransformation).build();
          
      FieldTransformation fieldTransformation = FieldTransformation.newBuilder()
        .addAllFields(headers)
        .setInfoTypeTransformations(transformations)
        .build();
          
      RecordTransformations recordTransformations = RecordTransformations.newBuilder().addFieldTransformations(fieldTransformation).build();

      DeidentifyConfig deidentifyConfig = DeidentifyConfig.newBuilder().setRecordTransformations(recordTransformations).build();

      //The Request to deidentify the given data is created for this project
      DeidentifyContentRequest request = DeidentifyContentRequest.newBuilder()
        .setParent(LocationName.of(projectId, "global").toString())
        .setItem(contentItem)
        .setInspectConfig(inspectConfig)
        .setDeidentifyConfig(deidentifyConfig)
        .build();

      //A response containing the deidentified table is returned and saved
      DeidentifyContentResponse response = dlp.deidentifyContent(request);
      table = response.getItem().getTable();
      dlp.close();
     }catch(Exception e){
      System.out.println(e);
     }
  }

  //This function deidentifies the selected info types with redaction
  public void redactionEncryption(){
     try (DlpServiceClient dlp = DlpServiceClient.create()) {
      //Sets the info types collected from the input csv file
      List<InfoType> finalITTypesList = new ArrayList<>();
      InfoType base; 
      for(int i = 0; i < itypeStringArray.length; i++){
        base = InfoType.newBuilder().setName(itypeStringArray[i]).build();
        finalITTypesList.add(base);
      }

      //The csv file uploaded is set for deidentification, and the info types to search for are selected
      ContentItem contentItem = ContentItem.newBuilder().setTable(table).build();
      InspectConfig inspectConfig = InspectConfig.newBuilder().addAllInfoTypes(finalITTypesList).build(); 

      PrimitiveTransformation primitiveTransformation = PrimitiveTransformation.newBuilder()
        .setRedactConfig(RedactConfig.getDefaultInstance())
        .build();

      InfoTypeTransformation infoTypeTransformation = InfoTypeTransformation.newBuilder()
        .setPrimitiveTransformation(primitiveTransformation)
        .build();
          
      InfoTypeTransformations transformations =InfoTypeTransformations.newBuilder().addTransformations(infoTypeTransformation).build();
          
      FieldTransformation fieldTransformation = FieldTransformation.newBuilder()
        .addAllFields(headers)
        .setInfoTypeTransformations(transformations)
        .build();
          
      RecordTransformations recordTransformations = RecordTransformations.newBuilder().addFieldTransformations(fieldTransformation).build();

      DeidentifyConfig deidentifyConfig = DeidentifyConfig.newBuilder().setRecordTransformations(recordTransformations).build();

      //The Request to deidentify the given data is created for this project
      DeidentifyContentRequest request = DeidentifyContentRequest.newBuilder()
        .setParent(LocationName.of(projectId, "global").toString())
        .setItem(contentItem)
        .setDeidentifyConfig(deidentifyConfig)
        .setInspectConfig(inspectConfig)
        .build();

      //A response containing the deidentified table is returned and saved
      DeidentifyContentResponse response = dlp.deidentifyContent(request);
      table = response.getItem().getTable();
      dlp.close();
     }catch(Exception e){
      System.out.println(e);
     }
  }

  //This function deidentifies the selected info types with replacement
  public void replacementEncryption(){

     try (DlpServiceClient dlp = DlpServiceClient.create()) {
      //Sets the info types collected from the input csv file
      List<InfoType> finalITTypesList = new ArrayList<>();
      InfoType base; 
      for(int i = 0; i < itypeStringArray.length; i++){
        base = InfoType.newBuilder().setName(itypeStringArray[i]).build();
        finalITTypesList.add(base);
      }

      //The csv file uploaded is set for deidentification, and the info types to search for are selected
      ContentItem contentItem = ContentItem.newBuilder().setTable(table).build();
      InspectConfig inspectConfig = InspectConfig.newBuilder().addAllInfoTypes(finalITTypesList).build();
      
      //The item to replace the selected info types with is selected
      ReplaceValueConfig replaceValueConfig = ReplaceValueConfig.newBuilder()
        .setNewValue(Value.newBuilder().setStringValue(replaceItem).build())
        .build();
          
      PrimitiveTransformation primitiveTransformation = PrimitiveTransformation.newBuilder().setReplaceConfig(replaceValueConfig).build();
         
      InfoTypeTransformation infoTypeTransformation = InfoTypeTransformation.newBuilder()
        .setPrimitiveTransformation(primitiveTransformation)
        .build();
          
      InfoTypeTransformations transformations =InfoTypeTransformations.newBuilder().addTransformations(infoTypeTransformation).build();
          
      FieldTransformation fieldTransformation = FieldTransformation.newBuilder()
        .addAllFields(headers)
        .setInfoTypeTransformations(transformations)
        .build();
          
      RecordTransformations recordTransformations = RecordTransformations.newBuilder().addFieldTransformations(fieldTransformation).build();

      DeidentifyConfig deidentifyConfig = DeidentifyConfig.newBuilder().setRecordTransformations(recordTransformations).build();

      //The Request to deidentify the given data is created for this project
      DeidentifyContentRequest request = DeidentifyContentRequest.newBuilder()
        .setParent(LocationName.of(projectId, "global").toString())
        .setItem(contentItem)
        .setDeidentifyConfig(deidentifyConfig)
        .setInspectConfig(inspectConfig)
        .build();

      //A response containing the deidentified table is returned and saved
      DeidentifyContentResponse response = dlp.deidentifyContent(request);
      table = response.getItem().getTable();
      dlp.close();
     }catch(Exception e){
      System.out.println(e);
     }
  }

  //This function decrypts files previously encrypted with FPE
  public void fpeDecryption(){
  	try (DlpServiceClient dlp = DlpServiceClient.create()) {
      //The csv file uploaded is set for deidentification, and the info types to search for are selected
      ContentItem contentItem = ContentItem.newBuilder().setTable(table).build();
      
      //The path to the originally used wrapping key is saved
      String keyPath = "projects/" + projectId + "/locations/global/keyRings/" + originalWrappingKeyRing + "/cryptoKeys/" + originalWrappingKey;
      Storage storageInstance = StorageOptions.newBuilder().setProjectId(projectId).build().getService();
      Blob testBlob = storageInstance.get(BlobId.of(protectedBucket, "wrapped_keys.json")); 
      String  blobContent = new String(testBlob.getContent());

      JSONParser parser = new JSONParser();
      JSONObject obj = (JSONObject) parser.parse(blobContent);
      JSONArray jsonArray = new JSONArray();
      jsonArray.add(obj);
      JSONObject object = (JSONObject) jsonArray.get(0);
      JSONArray keys = new JSONArray();
      keys = (JSONArray) object.get("keys");
      //System.out.println(keys.size());
      int i = 0;
      JSONObject temp = (JSONObject) keys.get(i);
     // System.out.println("Test1");
      
      while(temp != null){
      	temp = (JSONObject) keys.get(i);
      	String currName = (String) temp.get("name");

        if(currName.equals(uploadedFile)){
        	String wrappedKey = (String) temp.get("wrapped_key");
        	aesKeyFromFile = wrappedKey;
        }
        i++;
      }
      /*for(i = 0; i < keys.size(); i++){
      	System.out.println("current i: " + i);
      	JSONObject temp = (JSONObject) keys.get(i);
        String currName = (String) temp.get("name");

        if(currName.equals(uploadedFile)){
        	String wrappedKey = (String) temp.get("wrapped_key");
        	aesKeyFromFile = wrappedKey;
        	//System.out.println("test1");
        	System.out.println(wrappedKey);
 			System.out.println("test2");
        }
      }*/

      //The aes key is wrapped, so Google Cloud Platform can perform encryption with the wrapped key
      KmsWrappedCryptoKey kmsWrappedCryptoKey = KmsWrappedCryptoKey.newBuilder()
        .setWrappedKey(ByteString.copyFrom(BaseEncoding.base64().decode(aesKeyFromFile))) 
        .setCryptoKeyName(keyPath)
        .build();
      com.google.privacy.dlp.v2.CryptoKey cryptoKey = com.google.privacy.dlp.v2.CryptoKey.newBuilder().setKmsWrapped(kmsWrappedCryptoKey).build();

      //The surrogate info type given in the Configuration json is specified
      InfoType surrogateInfoType = InfoType.newBuilder().setName(originalSurrogateInfoTypeName).build();

      //The surrogate info type used when the data was initially encrypted is set
      CustomInfoType customInfoType = CustomInfoType.newBuilder()
            .setInfoType(surrogateInfoType)
            .setSurrogateType(CustomInfoType.SurrogateType.newBuilder().build())
            .build();
      //The initial surrogate info type used in the first encryption is set to be searched for
      InspectConfig inspectConfig = InspectConfig.newBuilder().addAllCustomInfoTypes(Arrays.asList(customInfoType)).build();

      //The key used to encrypt the original file, the original surrogate info type, and the alphabet used are put into the FPE Decryption config file
      CryptoReplaceFfxFpeConfig cryptoReplaceFfxFpeConfig = CryptoReplaceFfxFpeConfig.newBuilder()
        .setCryptoKey(cryptoKey)
        .setCustomAlphabet("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890@.-~!()+ ")
        .setSurrogateInfoType(surrogateInfoType)
        .build();

      PrimitiveTransformation primitiveTransformation = PrimitiveTransformation.newBuilder()
        .setCryptoReplaceFfxFpeConfig(cryptoReplaceFfxFpeConfig)
        .build();

      InfoTypeTransformation infoTypeTransformation = InfoTypeTransformation.newBuilder()
        .setPrimitiveTransformation(primitiveTransformation)
        .build();

      InfoTypeTransformations transformations = InfoTypeTransformations.newBuilder().addTransformations(infoTypeTransformation).build();

      DeidentifyConfig reidentifyConfig = DeidentifyConfig.newBuilder().setInfoTypeTransformations(transformations).build();

      //The Request to decrypt the given data is created for this project
      DeidentifyContentRequest request = DeidentifyContentRequest.newBuilder()
        .setParent(LocationName.of(projectId, "global").toString())
        .setItem(contentItem)
        .setInspectConfig(inspectConfig)
        .setDeidentifyConfig(reidentifyConfig)
        .build();
              
      //A response containing the decrypted table is returned and saved
      DeidentifyContentResponse response = dlp.deidentifyContent(request);         
      table = response.getItem().getTable();
      dlp.close();
    }catch(Exception e){
      System.out.println(e);
    }
  } 
}